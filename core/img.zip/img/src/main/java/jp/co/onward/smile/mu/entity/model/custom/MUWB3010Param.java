package jp.co.onward.smile.mu.entity.model.custom;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/** DTO */
@Getter
@Setter
public class MUWB3010Param implements Serializable {

    /** シリアルバージョンUID */
    private static final long serialVersionUID = 1L;

    /** パターン区分 */
    private String ptnKb;

    /** データ区分:予算/見通 */
    private String dataKb;

    /** 年度 */
    private String nnd;

    /** 会社 */
    private String kaiCd;

    /** 地区 */
    private String chikuCd;

    /** 本部 */
    private List<String> honBuList;

    /** 売場 */
    private String uribaCd1;

    /** 品番別 */
    private String uribaCd2;

    /** 予算① */
    private String yoSan1;

    /** 予算② */
    private String yoSan2;

    /** 普特 */
    private String futokuKb;

    /** 売上年月 */
    private String uriageYm;

    /** 上代1 */
    private Long jyodaiKg;
    
    /** 上代2 */
    private Long jyodai2Kg;

    /** 上代粗利1 */
    private Long jyodaiArariKg;

    /** 上代粗利2 */
    private Long jyodaiArari2Kg;

    /** 下代1 */
    private Long gedaiKg;

    /** 下代1 */
    private Long gedai2Kg;

    /** 下代粗利1 */
    private Long gedaiArariKg;

    /** 下代粗利2 */
    private Long gedaiArari2Kg;

    /** 更新日 */
    private String updateDt;

    /** 更新時間 */
    private String updateTm;

    /** 更新ユーザーＩＤ */
    private String updateUsrId;

    /** 更新プログラムＩＤ */
    private String updatePgmId;
    
    // 予算① 更新日時
    private String yosan1Updt;
    //予算① 更新者
    private String yosan1UpUsr;
    // 予算② 更新日時
    private String yosan2Updt;
    // 予算② 更新者
    private String yosan2UpUsr;

}
