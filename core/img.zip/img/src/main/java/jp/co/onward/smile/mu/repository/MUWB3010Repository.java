package jp.co.onward.smile.mu.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import jp.co.onward.smile.mu.entity.mapper.custom.MUWB3010Mapper;
import jp.co.onward.smile.mu.entity.model.custom.MUWB3010HeaderResult;
import jp.co.onward.smile.mu.entity.model.custom.MUWB3010Param;
import jp.co.onward.smile.mu.entity.model.custom.MUWB3010Result;
import lombok.RequiredArgsConstructor;

/**
 * 売上・粗利予算（売場別）Repository
 */
@Repository
@RequiredArgsConstructor
public class MUWB3010Repository {

    private final MUWB3010Mapper muwb3010Mapper;

    /**
     * 1.売上・粗利予算情報取得
     * 
     * @param param
     * @return
     */
    public List<MUWB3010Result> selectJouhou(final MUWB3010Param param) {
        return muwb3010Mapper.selectJouhou(param);
    }

    /**
     * 品番情報取得
     * 
     * @param param
     * @return
     */
    public List<String> selectHinBanInfo(final MUWB3010Param param) {
        return muwb3010Mapper.selectHinBanInfo(param);
    }

    /**
     * 売上・粗利予算ヘッダー情報取得
     * 
     * @param param
     * @return
     */
    public List<MUWB3010HeaderResult> selectUriageArariYosanInfo(final MUWB3010Param param) {
        return muwb3010Mapper.selectUriageArariYosanInfo(param);
    }

    /**
     * 18.処理対象外予算の退避
     *
     * @param param
     * @return
     */
    public int backupUriageArariYosanM(final MUWB3010Param param) {
        return muwb3010Mapper.backupUriageArariYosanM(param);
    }

    /**
     * 20.画面明細の一時表登録
     *
     * @param param
     * @param jsonList
     * @return
     */
    public int stageUriageArariYosanM(final MUWB3010Param param, final String jsonList) {
        return muwb3010Mapper.stageUriageArariYosanM(param, jsonList);
    }

    /**
     * 登録処理日時取得
     *
     * @return
     */
    public String selectRegistrationDateTime() {
        return muwb3010Mapper.selectRegistrationDateTime();
    }

    /**
     * 21.一時表の登録・更新情報設定
     *
     * @param param
     * @param jsonList
     * @return
     */
    public int updateUriageArariYosanTemp(final MUWB3010Param param, final String jsonList) {
        return muwb3010Mapper.updateUriageArariYosanTemp(param, jsonList);
    }

    /**
     * 19.既存明細の削除
     *
     * @param param
     * @return
     */
    public int deleteUriageArariYosanM(final MUWB3010Param param) {
        return muwb3010Mapper.deleteUriageArariYosanM(param);
    }

    /**
     * 3.売上・粗利予算明細再登録
     *
     * @param param
     * @return
     */
    public int insertUriageArariYosanM(final MUWB3010Param param) {
        return muwb3010Mapper.insertUriageArariYosanM(param);
    }

}
