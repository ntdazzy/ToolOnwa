package jp.co.onward.smile.mu.entity.mapper.custom;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import jp.co.onward.smile.mu.entity.model.custom.MUWB3010HeaderResult;
import jp.co.onward.smile.mu.entity.model.custom.MUWB3010Param;
import jp.co.onward.smile.mu.entity.model.custom.MUWB3010Result;

/**
 * 売上・粗利予算（売場別）Mapper
 */
public interface MUWB3010Mapper {

    /**
     * 売上・粗利予算情報取得
     * 
     * @param param
     * @return
     */
    List<MUWB3010Result> selectJouhou(@Param("param") MUWB3010Param param);

    /**
     * 品番情報取得
     * 
     * @param param
     * @return
     */
    List<String> selectHinBanInfo(@Param("param") MUWB3010Param param);

    /**
     * 売上・粗利予算ヘッダー情報取得
     * 
     * @param param
     * @return
     */
    List<MUWB3010HeaderResult> selectUriageArariYosanInfo(@Param("param") MUWB3010Param param);

    /**
     * 18.処理対象外予算の退避
     *
     * @param param
     * @return
     */
    int backupUriageArariYosanM(@Param("param") MUWB3010Param param);

    /**
     * 20.画面明細の一時表登録
     *
     * @param param
     * @param jsonList
     * @return
     */
    int stageUriageArariYosanM(@Param("param") MUWB3010Param param, @Param("jsonList") String jsonList);

    /**
     * 登録処理日時取得
     *
     * @return
     */
    String selectRegistrationDateTime();

    /**
     * 21.一時表の登録・更新情報設定
     *
     * @param param
     * @param jsonList
     * @return
     */
    int updateUriageArariYosanTemp(@Param("param") MUWB3010Param param, @Param("jsonList") String jsonList);

    /**
     * 19.既存明細の削除
     *
     * @param param
     * @return
     */
    int deleteUriageArariYosanM(@Param("param") MUWB3010Param param);

    /**
     * 3.売上・粗利予算明細再登録
     *
     * @param param
     * @return
     */
    int insertUriageArariYosanM(@Param("param") MUWB3010Param param);

}
