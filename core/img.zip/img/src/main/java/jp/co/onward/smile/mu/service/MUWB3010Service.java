package jp.co.onward.smile.mu.service;

import java.lang.reflect.Field;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.onward.smile.mu.component.annotation.BudgetField;
import jp.co.onward.smile.mu.component.exception.AplRollbackException;
import jp.co.onward.smile.mu.component.transaction.AplReadonlyTransactional;
import jp.co.onward.smile.mu.component.transaction.AplTransactional;
import jp.co.onward.smile.mu.constant.MessageIds;
import jp.co.onward.smile.mu.constant.SystemConsts;
import jp.co.onward.smile.mu.constant.enums.DeleteFlgEnum;
import jp.co.onward.smile.mu.entity.model.custom.MUWB3010ExResult;
import jp.co.onward.smile.mu.entity.model.custom.MUWB3010HeaderResult;
import jp.co.onward.smile.mu.entity.model.custom.MUWB3010Param;
import jp.co.onward.smile.mu.entity.model.custom.MUWB3010Result;
import jp.co.onward.smile.mu.entity.model.gen.MSockCtlAtyoM;
import jp.co.onward.smile.mu.entity.model.gen.MSockCtlAtyoMExample;
import jp.co.onward.smile.mu.entity.model.gen.MSoshiki;
import jp.co.onward.smile.mu.entity.model.gen.MSoshikiExample;
import jp.co.onward.smile.mu.entity.model.gen.MTokui;
import jp.co.onward.smile.mu.entity.model.gen.MTokuiExample;
import jp.co.onward.smile.mu.entity.model.gen.TUriageArariYosanH;
import jp.co.onward.smile.mu.entity.model.gen.TUriageArariYosanHExample;
import jp.co.onward.smile.mu.model.dto.MUWB3010CompleteInDto;
import jp.co.onward.smile.mu.model.dto.MUWB3010ConfirmInDto;
import jp.co.onward.smile.mu.model.dto.MUWB3010ConfirmOutDto;
import jp.co.onward.smile.mu.model.dto.MUWB3010SearchInDto;
import jp.co.onward.smile.mu.model.dto.MUWB3010SearchOutDto;
import jp.co.onward.smile.mu.model.dto.common.RequestInfoDto;
import jp.co.onward.smile.mu.model.form.MUWB3010Form;
import jp.co.onward.smile.mu.model.session.InitInfoSession;
import jp.co.onward.smile.mu.repository.MUWB3010Repository;
import jp.co.onward.smile.mu.repository.common.MSockCtlAtyoMRepository;
import jp.co.onward.smile.mu.repository.common.MSoshikiRepository;
import jp.co.onward.smile.mu.repository.common.MTokuiRepository;
import jp.co.onward.smile.mu.repository.common.TUriageArariYosanHRepository;
import jp.co.onward.smile.mu.service.common.MsgService;
import jp.co.onward.smile.mu.util.CommonUtils;
import lombok.RequiredArgsConstructor;

/**
 * 売上・粗利予算（売場別）Service
 */
@Service
@RequiredArgsConstructor
public class MUWB3010Service {
    /** 1,2数値 チェック */
    private static final Pattern PATTERN_NUMBER = Pattern.compile("[1,2]");
    private final MUWB3010Repository muwb3010Repository;
    private final MSoshikiRepository mSoshikiRepository;
    private final MTokuiRepository mTokuiRepository;
    private final MSockCtlAtyoMRepository mSockCtlAtyoMRepository;
    private final TUriageArariYosanHRepository tUriageArariYosanHRepository;
    private final MsgService msgService;
    private final InitInfoSession initInfoSession;
    private final RequestInfoDto requestInfoDto;
    private final String YOSAN_1 = "YOSAN_1";
    private final String YOSAN_2 = "YOSAN_2";

    /**
     * 本部のリストを設定
     * @param form
     * @return
     */
    public List<MSockCtlAtyoM> getHonBuList(final MUWB3010Form form) {
        final MSockCtlAtyoMExample mSockCtlAtyoMExample = new MSockCtlAtyoMExample();
        final MSockCtlAtyoMExample.Criteria mSockCtlAtyoMCriteria = mSockCtlAtyoMExample.createCriteria();
        // MSCAM.年度 = 表示部.年度
        mSockCtlAtyoMCriteria.andNndEqualTo(form.getNnd());
        // MSCAM.会社ＣＤ = 表示部.会社
        mSockCtlAtyoMCriteria.andKaiCdEqualTo(form.getKaiCd());
        // MSCAM.組織レベル区分 = "3"
        mSockCtlAtyoMCriteria.andLvKbEqualTo(SystemConsts.FIXED_3);
        // MSCAM.削除フラグ <> "1"
        mSockCtlAtyoMCriteria.andDelFgNotEqualTo(SystemConsts.FIXED_1);
        // 組織連番 ASC
        mSockCtlAtyoMExample.setOrderByClause("SOSI_SEQ ASC");

        return mSockCtlAtyoMRepository.selectByExample(mSockCtlAtyoMExample);
    }
    
    /**
     * 表示ボタン押下（JAVA処理）
     * 
     * @param inDto
     * @return
     */
    @AplReadonlyTransactional
    public MUWB3010SearchOutDto search(final MUWB3010SearchInDto inDto) {
        final MUWB3010SearchOutDto outDto = new MUWB3010SearchOutDto();
        // 2.売上・粗利予算情報取得処理
        // 2.1.売上・粗利予算ヘッダー情報取得SQLを呼び出し、売上・粗利予算ヘッダー情報を取得 ->「DB関連処理」シート＃No.1 売上・粗利予算情報取得
        final MUWB3010Param param = new MUWB3010Param();
        param.setDataKb(inDto.getDataKb());
        param.setKaiCd(inDto.getKaiCd());
        param.setNnd(inDto.getNnd());
        param.setChikuCd(inDto.getChikuCd());
        param.setHonBuList(inDto.getHonBuList());
        param.setUribaCd1(inDto.getUribaCd1());
        param.setUribaCd2(inDto.getUribaCd2());
        param.setYoSan1(inDto.getYoSan1());
        param.setYoSan2(inDto.getYoSan2());
        List<MUWB3010HeaderResult> selectUriageArariYosanInfoList = muwb3010Repository.selectUriageArariYosanInfo(param);
        for (int i = 0; i < selectUriageArariYosanInfoList.size(); i++) {
            final MUWB3010HeaderResult saveData = selectUriageArariYosanInfoList.get(i);
            if (StringUtils.isEmpty(saveData.getUpdateDt())) {
                // ①取得結果の更新日がNULLの場合、該当地区の新規登録フラグに"1"を設定する
                // ※後続処理のチェックで使用するため、「地区」「更新日」「更新時間」を全件保持する
                // ※0件の場合も後続処理へ
                saveData.setRegisterFlg(SystemConsts.REGISTERFLG_1);
            }     
        }
        outDto.setHeaderList(selectUriageArariYosanInfoList);
        List<MUWB3010Result> selectJouhouList = muwb3010Repository.selectJouhou(param);
        if (CollectionUtils.isEmpty(selectJouhouList)) {
            outDto.setRegisterFlg(SystemConsts.REGISTERFLG_1);
            outDto.setDataSource(new ArrayList<>());
        } else {
            List<MUWB3010ExResult> findall = dealwithData(selectJouhouList);
            outDto.setDataSource(findall);
        }
        // 3.ガイドメッセージの設定 ->「チェック仕様書」シート＃No.14 共通INFO
        // MSG-ID：WB0000007
        msgService.addToMessageHolder(msgService.getMsgList(MessageIds.WB0000007));
        return outDto;
    }

    /**
     * 入力完了ボタン
     * 
     * @param inDto
     * @return
     */
    @AplReadonlyTransactional
    public MUWB3010ConfirmOutDto confirm(MUWB3010ConfirmInDto inDto) {

        final MUWB3010ConfirmOutDto outDto = new MUWB3010ConfirmOutDto();

        final List<MUWB3010ExResult> saveList = inDto.getSaveList();
        final List<Integer[]> errorCellList = new ArrayList<>();
        final ArrayList<String> errorList = new ArrayList<>();
        final String yoSan1 = inDto.getYoSan1();
        final String yoSan2 = inDto.getYoSan2();

        // 2.2.組織マスタ取得SQLを呼び出し、組織マスタ情報を取得 ->「DB関連処理」シート＃No.6 組織マスタ取得
        final MSoshikiExample mSoshikiExample = new MSoshikiExample();
        final MSoshikiExample.Criteria mSoshikiCriteria = mSoshikiExample.createCriteria();
        // MS.管理領域 = "10"＋表示部.会社 AND
        // MS.有効開始日 <= 表示部.年度の終了日 AND
        // MS.有効終了日 >= 表示部.年度の終了日 AND
        // MS.レベル区分 = "5"
        // MS.削除フラグ <> "1"
        mSoshikiCriteria.andKanriRyoikiEqualTo(SystemConsts.KAN_RI_10 + inDto.getKaiCd());
        mSoshikiCriteria.andYukoStaDtLessThanOrEqualTo(
                SystemConsts.NND_20 + (Integer.parseInt(inDto.getNnd()) + 1) + SystemConsts.MONTH_DAY_0229);
        mSoshikiCriteria.andYukoEndDtGreaterThanOrEqualTo(
                SystemConsts.NND_20 + (Integer.parseInt(inDto.getNnd()) + 1) + SystemConsts.MONTH_DAY_0229);
        mSoshikiCriteria.andLvKbEqualTo(SystemConsts.LVKB_5);
        mSoshikiCriteria.andDelFgNotEqualTo(DeleteFlgEnum.DELETE_STATUS.getStatus());
        final List<MSoshiki> findMSoshiki = mSoshikiRepository.selectByExample(mSoshikiExample);

        // 2.4.得意先マスタ取得SQLを呼び出し、得意先マスタ情報を取得 ->「DB関連処理」シート＃No.7 得意先マスタ取得
        // (抽出条件）
        // MK.勘定グループＣＤ = "Z002"
        // MK.2桁会社コード = "10" + 表示部.会社
        // MK.削除フラグ <> "1"
        final MTokuiExample mTokuiExample = new MTokuiExample();
        final MTokuiExample.Criteria mTokuiCriteria = mTokuiExample.createCriteria();
        mTokuiCriteria.andKanjoGrpCdEqualTo(SystemConsts.KANJO_GRP_CD);
        mTokuiCriteria.andKaiCdEqualTo(inDto.getKaiCd());
        mTokuiCriteria.andDelFgNotEqualTo(DeleteFlgEnum.DELETE_STATUS.getStatus());
        final List<MTokui> mTokuiList = mTokuiRepository.selectByExample(mTokuiExample);

        // 2.入力項目のチェック （※全行一括チェック）
        // 2.1.入力規制チェック ->「チェック仕様書」シート＃No.1 入力規制チェック
        // 2.1.1.必須項目チェック、文字種チェック、桁数チェックを実施する
        for (int i = 0; i < saveList.size(); i++) {
            errorList.clear();
            final MUWB3010ExResult saveData = saveList.get(i);
            final String uribaCd = saveData.getUribaCd();
            final String chikuCd = saveData.getChikuCd();
            final String hinbanCd = saveData.getHinbanCd();
            final String futokuKb = saveData.getFutokuKb();

            if (StringUtils.isEmpty(chikuCd)) {
                errorList.add(msgService.getMsg(MessageIds.WB0000039, "地区", "半角数字", "2桁"));
                errorCellList.add(new Integer[] { i + 2, 1 });
            } else {
                if (!CommonUtils.isDigit(chikuCd) || !CommonUtils.isLength(chikuCd, 2,2)) {
                    errorList.add(msgService.getMsg(MessageIds.WB0000039, "地区", "半角数字", "2桁"));
                    errorCellList.add(new Integer[] { i + 2, 1 });
                }
            }

            if (StringUtils.isEmpty(uribaCd)) {
                errorList.add(msgService.getMsg(MessageIds.WB0000039, "売場", "半角数字", "10桁以下"));
                errorCellList.add(new Integer[] { i + 2, 2 });
            } else {
                if (!CommonUtils.isDigit(uribaCd) || !CommonUtils.isLength(uribaCd, 10)) {
                    errorList.add(msgService.getMsg(MessageIds.WB0000039, "売場", "半角数字", "10桁以下"));
                    errorCellList.add(new Integer[] { i + 2, 2 });
                }
            }

            if (StringUtils.isEmpty(hinbanCd)) {
                errorList.add(msgService.getMsg(MessageIds.WB0000039, "品番", "半角数字", "4桁"));
                errorCellList.add(new Integer[] { i + 2, 3 });
            } else {
                if (!CommonUtils.isDigit(hinbanCd) || !CommonUtils.isLength(hinbanCd, 4, 4)) {
                    errorList.add(msgService.getMsg(MessageIds.WB0000039, "品番", "半角数字", "4桁"));
                    errorCellList.add(new Integer[] { i + 2, 3 });
                }
            }

            if (StringUtils.isEmpty(futokuKb)) {
                errorList.add(msgService.getMsg(MessageIds.WB0000039, "普特", "半角数字", "1桁"));
                errorCellList.add(new Integer[] { i + 2, 4 });
            } else {
                if (!CommonUtils.isDigit(futokuKb) || !CommonUtils.isLength(futokuKb, 1, 1)) {
                    errorList.add(msgService.getMsg(MessageIds.WB0000039, "普特", "半角数字", "1桁"));
                    errorCellList.add(new Integer[] { i + 2, 4 });
                } else {
                    if (!PATTERN_NUMBER.matcher(futokuKb).matches()) {
                        errorList.add(msgService.getMsg(MessageIds.WB0000018, "普特", "1または2"));
                        errorCellList.add(new Integer[] { i + 2, 4 });
                    }
                }
            }

            Field[] declaredFields = saveData.getClass().getDeclaredFields();

            for (int n = 9; n < declaredFields.length - 5; n++) { 
                try {
                    declaredFields[n].setAccessible(true);
                    String str = (String) declaredFields[n].get(saveData);
                    if (str == null) {
                        continue;
                    }

                    BudgetField annotation = declaredFields[n].getAnnotation(BudgetField.class);
                    if (annotation != null) {
                        String group = annotation.group();

                         // ※表示部の予算①を選択する場合、上代②～下代粗利②以外の項目をチェック処理実施する
                        if (StringUtils.equals(yoSan1, SystemConsts.YOSAN_1) && !StringUtils.equals(yoSan2, SystemConsts.YOSAN_2)) {
                            if (!YOSAN_1.equals(group)) {
                                continue;
                            }
                        } 
                        // ※表示部の予算②を選択する場合、上代②～下代粗利②以外の項目をチェック処理実施する
                        else if (!StringUtils.equals(yoSan1, SystemConsts.YOSAN_1) && StringUtils.equals(yoSan2, SystemConsts.YOSAN_2)) {
                            if (!YOSAN_2.equals(group)) {
                                continue;
                            }
                        }
                    }

                    boolean isValidLength = str != null && !str.isEmpty() && CommonUtils.isMinusNumLength(str, 0, 13);
                    if (!CommonUtils.isMinusNumber(str) || !isValidLength) {
                        int m = (n-1) % 8;
                        String name = SystemConsts.EMPTY;
                        switch (m) {
                            case 0:
                                name = "上代①";
                                break;
                            case 1:
                                name = "上代粗利①";
                                break;
                            case 2:
                                name = "下代①";
                                break;

                            case 3:
                                name = "下代粗利①";
                                break;

                            case 4:
                                name = "上代②";
                                break;

                            case 5:
                                name = "上代粗利②";
                                break;

                            case 6:
                                name = "下代②";
                                break;

                            case 7:
                                name = "下代粗利②";
                                break;

                            default:
                                break;
                        }
                        errorList.add(msgService.getMsg(MessageIds.WB0000039, name, "数値", "13桁以下"));
                        errorCellList.add(new Integer[] { i + 2, n - 4 }); 
                    }
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }

            // 2.3.組織マスタ存在チェック
            // 2.3.1.入力された表示部.会社の2桁目 + 明細部.地区＋明細部.品番が2.1.で取得した組織マスタに存在するかチェック
            // ->「チェック仕様書」シート＃No.2 組織マスタ存在チェック
            if (findMSoshiki.stream().noneMatch(mSoshiki -> StringUtils.equals(mSoshiki.getGenkaCenter(),
                    StringUtils.substring(inDto.getKaiCd(), 1, 2) + saveData.getChikuCd() + saveData.getHinbanCd()))) {
                errorList.add(msgService.getMsg(MessageIds.WB0000016,
                        "地区-品番", "組織"));
                errorCellList.add(new Integer[] { i + 2, 3 });
            }

            // 2.5.得意先マスタ存在チェック
            // 2.5.1.入力された売場が2.3.で取得した得意先マスタに存在するかチェック ->「チェック仕様書」シート＃No.7 得意先マスタ存在チェック
            if (mTokuiList.stream()
                    .noneMatch(mTokui -> StringUtils.equals(saveData.getUribaCd(), mTokui.getTokuiCd()))) {
                errorList.add(msgService.getMsg(MessageIds.WB0000016,
                        "売場", "得意先"));
                errorCellList.add(new Integer[] { i + 2, 2 });
            }
            // 2.5.重複チェック
            // 2.5.1.地区、売場、品番、普特の単位で重複チェック ->「チェック仕様書」シート＃No.3 重複チェック
            Long count = saveList.stream()
                    .filter(item -> StringUtils.equals(item.getChikuCd(), saveData.getChikuCd()))
                    .filter(item -> StringUtils.equals(item.getUribaCd(), saveData.getUribaCd()))
                    .filter(item -> StringUtils.equals(item.getHinbanCd(), saveData.getHinbanCd()))
                    .filter(item -> StringUtils.equals(item.getFutokuKb(), saveData.getFutokuKb())).count();
            if (count > 1) {
                errorList.add(msgService.getMsg(MessageIds.WB0000024, "組合せ"));
                errorCellList.add(new Integer[] { i + 2, 1 });
                errorCellList.add(new Integer[] { i + 2, 2 });
                errorCellList.add(new Integer[] { i + 2, 3 });
                errorCellList.add(new Integer[] { i + 2, 4 });
            }

            // 2.8.品番整合性チェック（※検索部の本部に入力がある場合）
            if(CollectionUtils.isNotEmpty(inDto.getHonBuList())){
                // 2.8.1.品番情報取得SQLを呼び出し、本部に紐づく品番情報を取得
                final MUWB3010Param param = new MUWB3010Param();
                param.setKaiCd(inDto.getKaiCd());
                param.setNnd(inDto.getNnd());
                param.setHonBuList(inDto.getHonBuList());
                List<String> selectHinBanList = muwb3010Repository.selectHinBanInfo(param);
                if(!selectHinBanList.contains(saveData.getHinbanCd())){
                    errorList.add(msgService.getMsg(MessageIds.WB0000059, "品番","A帳組織コントロール"));
                    errorCellList.add(new Integer[] { i + 2, 3 });
                }
            }
            //2.9.地区整合性チェック（※検索部の地区に入力がある場合）
            if(StringUtils.isNotEmpty(inDto.getChikuCd())){
                //2.9.1.検索部の地区と明細部の地区の整合性チェック
                if(!StringUtils.equals(inDto.getChikuCd(), saveData.getChikuCd())){
                    errorList.add(msgService.getMsg(MessageIds.WB3010001));
                    errorCellList.add(new Integer[] { i + 2, 1 });
                }
            }

            saveData.setErrInfo(StringUtils.join(errorList, SystemConsts.EMPTY));
        }
        // 4. 以上の1～3 のチェックでは、エラーがあった場合、
        if (CollectionUtils.isNotEmpty(errorCellList)) {
            // 上記チェックでエラーが存在する場合、表示部にエラーメッセージを表示・処理中断
            msgService.addToMessageHolder(msgService.getMsgList(MessageIds.WB0000033));
        }
        if (CollectionUtils.isEmpty(errorCellList)) {
            // ガイドメッセージの設定
            msgService.addToMessageHolder(msgService.getMsgList(MessageIds.WB0000008));
        }

        outDto.setErrorCellList(errorCellList);
        return outDto;
    }

    /**
     * 実行ボタン
     * 
     * @param inDto
     */
    @AplTransactional
    public void complete(final MUWB3010CompleteInDto inDto) {
        final List<MUWB3010ExResult> bkList = inDto.getSaveSourceHidden();
        final List<MUWB3010ExResult> saveList = inDto.getSaveList();
        final List<MUWB3010HeaderResult> headerList = inDto.getHeaderList();
        // 2.売上・粗利予算テーブル情報更新処理を実施
        // 1) 新規登録の場合（新規登録フラグが"1"の場合）
        for (int i = 0; i < headerList.size(); i++) {
            final MUWB3010HeaderResult saveData = headerList.get(i);
            if (StringUtils.equals(saveData.getRegisterFlg(), SystemConsts.REGISTERFLG_1)) {
                // 2.1.売上・粗利予算データ登録SQLを呼び出し、売上・粗利予算情報に登録する
                // 2.1.1.売上・粗利予算ヘッダを登録する ->「DB関連処理」シート＃No.2 売上・粗利予算ヘッダ登録
                // ①一意制約違反の場合
                // 表示部にエラーメッセージを表示・処理中断
                // MSG-ID：WB0000003 ->「チェック仕様書」シート＃No.8 排他チェック
                final TUriageArariYosanH row = new TUriageArariYosanH();
                // TUAYH.パターン区分 "20"
                row.setPtnKb(SystemConsts.PTN_KB_20);
                // TUAYH.年度 表示部.年度
                row.setNnd(inDto.getNnd());
                // TUAYH.データ区分 表示部.予算/見通（1:予算、2:見通し）
                row.setDataKb(inDto.getDataKb());
                // TUAYH.会社CD 表示部.会社CD
                row.setKaiCd(inDto.getKaiCd());
                // TUAYH.地区CD 汎用マスタ.コード ※非表示項目
                row.setChikuCd(saveData.getKCd());
                // TUAYH.登録日 ＤＢシステム日付 （YYYYMMDD形式）
                row.setCreateDt(requestInfoDto.getRequestDt());
                // TUAYH.登録時間 ＤＢシステム日付 （HH24MISS形式）
                row.setCreateTm(requestInfoDto.getRequestTm());
                // TUAYH.登録ユーザーＩＤ 初期処理部品．ユーザーＩＤ
                row.setCreateUsrId(initInfoSession.getUserId());
                // TUAYH.登録プログラムＩＤ MUWB3010
                row.setCreatePgmId(requestInfoDto.getPgmId());
                // TUAYH.更新日 ＤＢシステム日付 （YYYYMMDD形式）
                row.setUpdateDt(requestInfoDto.getRequestDt());
                // TUAYH.更新時間 ＤＢシステム日付 （HH24MISS形式）
                row.setUpdateTm(requestInfoDto.getRequestTm());
                // TUAYH.更新ユーザーＩＤ 初期処理部品．ユーザーＩＤ
                row.setUpdateUsrId(initInfoSession.getUserId());
                // TUAYH.更新プログラムＩＤ MUWB3010
                row.setUpdatePgmId(requestInfoDto.getPgmId());
                // TUAYH.削除フラグ "0"
                row.setDelFg(DeleteFlgEnum.UN_DELETE_STATUS.getStatus());
                try {
                    tUriageArariYosanHRepository.insert(row);
                } catch (DuplicateKeyException e) {
                    msgService.addToMessageHolder(msgService.getMsgList(MessageIds.WB0000003));
                    throw new AplRollbackException();
                }
            } else {
                // 2) 更新の場合
                // 2.1.売上・粗利予算ヘッダのデータ更新SQLを呼び出し、売上・粗利予算ヘッダ情報を更新する
                // 2.1.1.売上・粗利予算ヘッダを更新する ->「DB関連処理」シート＃No.4 売上・粗利予算ヘッダ更新
                final TUriageArariYosanHExample hExample = new TUriageArariYosanHExample();
                final TUriageArariYosanHExample.Criteria hCriteria = hExample.createCriteria();
                // (抽出条件）
                // TKSYH.パターン区分 = "20" AND
                hCriteria.andPtnKbEqualTo(SystemConsts.PTN_KB_20);
                // TKSYH.年度 = 表示部.年度 AND
                hCriteria.andNndEqualTo(inDto.getNnd());
                // TKSYH.データ区分 = 表示部.予算/見通 AND
                hCriteria.andDataKbEqualTo(inDto.getDataKb());
                // TKSYH.会社CD = 表示部.会社 AND
                hCriteria.andKaiCdEqualTo(inDto.getKaiCd());
                // TUAYH.地区CD (非表示項目).地区CD
                hCriteria.andChikuCdEqualTo(saveData.getKCd());
                // TUAYH.更新日 (非表示項目).更新日
                hCriteria.andUpdateDtEqualTo(saveData.getUpdateDt());
                // TUAYH.更新時間 (非表示項目).更新時間
                hCriteria.andUpdateTmEqualTo(saveData.getUpdateTm());

                final TUriageArariYosanH hRow = new TUriageArariYosanH();
                // TKSYH.更新日 ＤＢシステム日付 （YYYYMMDD形式）
                hRow.setUpdateDt(requestInfoDto.getRequestDt());
                // TKSYH.更新時間 ＤＢシステム日付 （HH24MISS形式）
                hRow.setUpdateTm(requestInfoDto.getRequestTm());
                // TKSYH.更新ユーザーＩＤ 初期処理部品．ユーザーＩＤ
                hRow.setUpdateUsrId(initInfoSession.getUserId());
                // TKSYH.更新プログラムＩＤ MUWB3010
                hRow.setUpdatePgmId(requestInfoDto.getPgmId());
                // TKSYH.削除フラグ "0"
                hRow.setDelFg(DeleteFlgEnum.UN_DELETE_STATUS.getStatus());

                int count = tUriageArariYosanHRepository.updateByExampleSelective(hRow, hExample);
                if (count == 0) {
                    // ①更新した結果の件数が０件の場合、排他エラー
                    // 表示部にエラーメッセージを表示・処理中断
                    // MSG-ID：WB0000003 ->「チェック仕様書」シート＃No.8 排他チェック
                    msgService.addToMessageHolder(msgService.getMsgList(MessageIds.WB0000003));
                    throw new AplRollbackException();
                } 
            }
        }

        // 2.2.売上・粗利予算明細を再登録する
        replaceDetails(saveList, bkList, inDto);

        // 2.3.登録完了メッセージを表示
        // ガイドメッセージの設定
        msgService.addToMessageHolder(msgService.getMsgList(MessageIds.WB0000009));
    }

    /** 明細の月（会計年度の並び：3月～翌2月） */
    private static final List<String> DETAIL_MONTHS =
            Arrays.asList("03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "01", "02");

    /** 一時表登録の分割件数（画面明細単位） */
    private static final int DETAIL_BATCH_SIZE = 1000;

    /**
     * 2.2.売上・粗利予算明細を再登録する
     */
    private void replaceDetails(final List<MUWB3010ExResult> saveList,
                                final List<MUWB3010ExResult> bkList,
                                final MUWB3010CompleteInDto inDto) {
        final boolean allMode = isYosanAllCheck(inDto.getYoSan1(), inDto.getYoSan2());
        final boolean useY1 = allMode || StringUtils.equals(inDto.getYoSan1(), SystemConsts.YOSAN_1);
        final boolean useY2 = allMode || StringUtils.equals(inDto.getYoSan2(), SystemConsts.YOSAN_2);
        final MUWB3010Param param = new MUWB3010Param();
        param.setNnd(inDto.getNnd());
        param.setDataKb(inDto.getDataKb());
        param.setKaiCd(inDto.getKaiCd());
        param.setChikuCd(inDto.getChikuCd());
        param.setHonBuList(inDto.getHonBuList());
        param.setUribaCd1(inDto.getUribaCd1());
        param.setUribaCd2(inDto.getUribaCd2());
        param.setYoSan1(useY1 ? SystemConsts.YOSAN_1 : SystemConsts.FIXED_0);
        param.setYoSan2(useY2 ? SystemConsts.YOSAN_2 : SystemConsts.FIXED_0);
        param.setUpdateUsrId(initInfoSession.getUserId());
        param.setUpdatePgmId(requestInfoDto.getPgmId());

        try {
            // 2.2.1.処理対象外予算の退避 ->「DB関連処理」シート＃No.18 処理対象外予算の退避
            if (!allMode) {
                muwb3010Repository.backupUriageArariYosanM(param);
            }
            // 2.2.2.画面明細の一時表登録 ->「DB関連処理」シート＃No.20 画面明細の一時表登録
            final String registrationDateTime = muwb3010Repository.selectRegistrationDateTime();
            param.setUpdateDt(registrationDateTime.substring(0, 8));
            param.setUpdateTm(registrationDateTime.substring(8, 14));
            for (int i = 0; i < saveList.size(); i += DETAIL_BATCH_SIZE) {
                final List<MUWB3010ExResult> details = saveList.subList(i, Math.min(i + DETAIL_BATCH_SIZE, saveList.size()));
                muwb3010Repository.stageUriageArariYosanM(param, buildStageJson(details, inDto, useY1, useY2));
            }
            // 2.2.3.一時表の登録・更新情報の設定 ->「DB関連処理」シート＃No.21 一時表の登録・更新情報設定
            final List<Map<String, String>> updateRows = buildUpdateRows(saveList, bkList, useY1, useY2);
            for (int i = 0; i < updateRows.size(); i += DETAIL_BATCH_SIZE) {
                muwb3010Repository.updateUriageArariYosanTemp(param,
                        toJson(updateRows.subList(i, Math.min(i + DETAIL_BATCH_SIZE, updateRows.size()))));
            }
            // 2.2.4.既存明細の削除 ->「DB関連処理」シート＃No.19 既存明細の削除
            muwb3010Repository.deleteUriageArariYosanM(param);
            // 2.2.5.売上・粗利予算明細の再登録 ->「DB関連処理」シート＃No.3 売上・粗利予算明細再登録
            muwb3010Repository.insertUriageArariYosanM(param);
        } catch (Exception e) {
            // エラーが発生した場合、ヘッダーの登録／更新を含めて全体をロールバックする。
            throw new AplRollbackException(e.getMessage(), e);
        }
    }

    /**
     * 明細部データを月別・予算別の登録用データに変換する
     */
    private String buildStageJson(final List<MUWB3010ExResult> saveList,
                                  final MUWB3010CompleteInDto inDto,
                                  final boolean useY1, final boolean useY2) {
        final List<Map<String, Object>> rows = new ArrayList<>();
        for (final MUWB3010ExResult data : saveList) {
            for (final String month : DETAIL_MONTHS) {
                final boolean hasData = (useY1 && !isGroupBlank(data, month, YOSAN_1))
                        || (useY2 && !isGroupBlank(data, month, YOSAN_2));
                if (!hasData) {
                    continue;
                }
                for (int yosan = 1; yosan <= 2; yosan++) {
                    if ((yosan == 1 && !useY1) || (yosan == 2 && !useY2)) {
                        continue;
                    }
                    final Map<String, Object> row = new HashMap<>();
                    row.put("chikuCd", data.getChikuCd());
                    row.put("uribaCd", data.getUribaCd());
                    row.put("hinbanCd", data.getHinbanCd());
                    row.put("futokuKb", data.getFutokuKb());
                    row.put("uriageYm", toUriageYm(inDto, month));
                    row.put("prctrCd", buildPrctr(inDto, data));
                    row.put("yosanKb", yosan == 1 ? SystemConsts.YOSAN_1 : SystemConsts.YOSAN_2);
                    final Long[] amounts = yosan == 1 ? readGroup1(data, month) : readGroup2(data, month);
                    row.put("jyodaiKg", amounts[0]);
                    row.put("jyodaiArariKg", amounts[1]);
                    row.put("gedaiKg", amounts[2]);
                    row.put("gedaiArariKg", amounts[3]);
                    rows.add(row);
                }
            }
        }
        return toJson(rows);
    }

    /**
     * 表示時と登録時の明細から、キーごとの更新用データを生成する
     */
    private List<Map<String, String>> buildUpdateRows(final List<MUWB3010ExResult> saveList,
                                                     final List<MUWB3010ExResult> bkList,
                                                     final boolean useY1, final boolean useY2) {
        final Map<String, MUWB3010ExResult> beforeMap = new LinkedHashMap<>();
        for (final MUWB3010ExResult data : bkList) {
            beforeMap.put(getKey(data), data);
        }
        final Map<String, MUWB3010ExResult> deletedMap = new LinkedHashMap<>(beforeMap);
        final Map<String, Map<String, String>> updateMap = new LinkedHashMap<>();
        for (final MUWB3010ExResult data : saveList) {
            final String key = getKey(data);
            final MUWB3010ExResult before = beforeMap.get(key);
            final boolean changedY1 = useY1 && (before == null || hasDifference(data, before, YOSAN_1));
            final boolean changedY2 = useY2 && (before == null || hasDifference(data, before, YOSAN_2));
            updateMap.put(key, buildUpdateRow(data, changedY1, changedY2));
            deletedMap.remove(key);
        }
        // キー変更・行削除の変更前キーも対象とする。
        for (final MUWB3010ExResult data : deletedMap.values()) {
            updateMap.put(getKey(data), buildUpdateRow(data, useY1, useY2));
        }
        return new ArrayList<>(updateMap.values());
    }

    /** 明細キーと予算別の変更フラグを設定する */
    private Map<String, String> buildUpdateRow(final MUWB3010ExResult data,
                                              final boolean changedY1, final boolean changedY2) {
        final Map<String, String> row = new HashMap<>();
        row.put("chikuCd", data.getChikuCd());
        row.put("uribaCd", data.getUribaCd());
        row.put("hinbanCd", data.getHinbanCd());
        row.put("futokuKb", data.getFutokuKb());
        row.put("yosan1UpdateFlg", changedY1 ? SystemConsts.FIXED_1 : SystemConsts.FIXED_0);
        row.put("yosan2UpdateFlg", changedY2 ? SystemConsts.FIXED_1 : SystemConsts.FIXED_0);
        return row;
    }

    /** 登録用データをJSON配列文字列に変換する */
    private String toJson(final Object data) {
        try {
            return new ObjectMapper().writeValueAsString(data);
        } catch (JsonProcessingException e) {
            throw new AplRollbackException(e.getMessage(), e);
        }
    }

    /** 売上年月を生成する（"20"＋（月が1～2なら年度＋1、それ以外は年度）＋月）。 */
    private String toUriageYm(final MUWB3010CompleteInDto inDto, final String month) {
        final int yearOffset = Integer.parseInt(month) <= 2 ? 1 : 0;
        return SystemConsts.NND_20 + (Integer.parseInt(inDto.getNnd()) + yearOffset) + month;
    }

    /** 利益センタCD（会社の2桁目＋地区＋品番）。 */
    private String buildPrctr(final MUWB3010CompleteInDto inDto, final MUWB3010ExResult data) {
        return StringUtils.substring(inDto.getKaiCd(), 1, 2) + data.getChikuCd() + data.getHinbanCd();
    }

    /** 当月の予算①数値 [上代,上代粗利,下代,下代粗利]。 */
    private Long[] readGroup1(final MUWB3010ExResult d, final String m) {
        return new Long[] {
            parseLongZero(getFieldValue(d, "jyo" + m + "daiKg")),
            parseLongZero(getFieldValue(d, "jyo" + m + "daiArariKg")),
            parseLongZero(getFieldValue(d, "ge" + m + "daiKg")),
            parseLongZero(getFieldValue(d, "ge" + m + "daiArariKg"))
        };
    }

    /** 当月の予算②数値 [上代②,上代粗利②,下代②,下代粗利②]。 */
    private Long[] readGroup2(final MUWB3010ExResult d, final String m) {
        return new Long[] {
            parseLongZero(getFieldValue(d, "jyo" + m + "dai2Kg")),
            parseLongZero(getFieldValue(d, "jyo" + m + "daiArari2Kg")),
            parseLongZero(getFieldValue(d, "ge" + m + "dai2Kg")),
            parseLongZero(getFieldValue(d, "ge" + m + "daiArari2Kg"))
        };
    }

    /** 当月の指定グループが全て空白か。 */
    private boolean isGroupBlank(final MUWB3010ExResult d, final String m, final String group) {
        final String[] fields = YOSAN_1.equals(group)
                ? new String[] {"jyo" + m + "daiKg", "jyo" + m + "daiArariKg", "ge" + m + "daiKg", "ge" + m + "daiArariKg"}
                : new String[] {"jyo" + m + "dai2Kg", "jyo" + m + "daiArari2Kg", "ge" + m + "dai2Kg", "ge" + m + "daiArari2Kg"};
        for (final String f : fields) {
            if (StringUtils.isNotBlank(getFieldValue(d, f))) {
                return false;
            }
        }
        return true;
    }

    // レコードのKeyを取得
    private String getKey(MUWB3010ExResult data) {
        return data.getChikuCd() + "|" + data.getUribaCd() + "|" + data.getHinbanCd() + "|" + data.getFutokuKb();
    }

    // データが編集したかどうかチェック
    private boolean hasDifference(MUWB3010ExResult a, MUWB3010ExResult b, String group) {
        Field[] fields = MUWB3010ExResult.class.getDeclaredFields();
        for (Field field : fields) {
            BudgetField annotation = field.getAnnotation(BudgetField.class);
            if (annotation != null && annotation.group().equals(group)) {
                field.setAccessible(true);
                try {
                    Object aValue = field.get(a);
                    Object bValue = field.get(b);
                    if (!Objects.equals(aValue, bValue)) {
                        return true;
                    }
                } catch (IllegalAccessException e) {
                    throw new AplRollbackException(e.getMessage(), e);
                }
            }
        }
        return false;
    }

    /**
     * データ処理
     * 
     * @param list
     * @return
     */
    private List<MUWB3010ExResult> dealwithData(List<MUWB3010Result> list) {

        // 地区、売場cd、品番cd、普特区分groupingBy
        Map<String, List<MUWB3010Result>> maps = list.stream()
                .collect(Collectors.groupingBy(o -> o.getChikuCd() + o.getUribaCd() + o.getHinbanCd() + o.getFutokuKb(),
                        LinkedHashMap::new, Collectors.toList()));

        List<MUWB3010ExResult> exResultList = new ArrayList<>();
        // 売場cd、品番cd、普特区よりGROUPBY
        Iterator<Map.Entry<String, List<MUWB3010Result>>> it = maps.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, List<MUWB3010Result>> entry = it.next();
            List<MUWB3010Result> resultList = entry.getValue();
            final MUWB3010ExResult exResult = new MUWB3010ExResult();
            for (MUWB3010Result muwb3010Result : resultList) {
                final String uriageYm = StringUtils.substring(muwb3010Result.getUriageYm(), 4, 6);
                exResult.setChikuCd(muwb3010Result.getChikuCd());
                exResult.setUribaCd(muwb3010Result.getUribaCd());
                exResult.setHinbanCd(muwb3010Result.getHinbanCd());
                exResult.setFutokuKb(muwb3010Result.getFutokuKb());

                final String ys1Udts = muwb3010Result.getYosan1Updt();
                if(ys1Udts != null && ys1Udts.trim().length() == 14 ) {
                    DateTimeFormatter disYs1UpdateTsBefore = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
                    DateTimeFormatter disYs1UpdateTsAfter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                    exResult.setYosan1Updt(LocalDateTime.parse(ys1Udts, disYs1UpdateTsBefore).format(disYs1UpdateTsAfter));
                    exResult.setYosan1UpUsr(muwb3010Result.getYosan1UpUsr());
                }

                final String ys2Udts = muwb3010Result.getYosan2Updt();
                if(ys2Udts != null && ys2Udts.trim().length() == 14 ) {
                    DateTimeFormatter disYs2UpdateTsBefore = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
                    DateTimeFormatter disYs2UpdateTsAfter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                    exResult.setYosan2Updt(LocalDateTime.parse(ys2Udts, disYs2UpdateTsBefore).format(disYs2UpdateTsAfter));
                    exResult.setYosan2UpUsr(muwb3010Result.getYosan2UpUsr());
                }
                switch (uriageYm) {
                    case "01":
                        exResult.setGe01daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe01daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe01dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe01daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo01daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo01daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo01dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo01daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "02":
                        exResult.setGe02daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe02daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe02dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe02daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo02daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo02daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo02dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo02daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "03":
                        exResult.setGe03daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe03daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe03dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe03daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo03daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo03daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo03dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo03daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "04":
                        exResult.setGe04daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe04daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe04dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe04daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo04daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo04daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo04dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo04daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "05":
                        exResult.setGe05daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe05daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe05dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe05daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo05daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo05daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo05dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo05daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "06":
                        exResult.setGe06daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe06daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe06dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe06daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo06daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo06daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo06dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo06daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "07":
                        exResult.setGe07daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe07daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe07dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe07daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo07daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo07daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo07dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo07daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "08":
                        exResult.setGe08daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe08daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe08dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe08daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo08daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo08daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo08dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo08daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "09":
                        exResult.setGe09daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe09daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe09dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe09daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo09daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo09daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo09dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo09daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "10":
                        exResult.setGe10daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe10daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe10dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe10daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo10daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo10daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo10dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo10daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "11":
                        exResult.setGe11daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe11daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe11dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe11daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo11daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo11daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo11dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo11daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    case "12":
                        exResult.setGe12daiKg(muwb3010Result.getGedaiKg());
                        exResult.setGe12daiArariKg(muwb3010Result.getGedaiArariKg());
                        exResult.setGe12dai2Kg(muwb3010Result.getGedai2Kg());
                        exResult.setGe12daiArari2Kg(muwb3010Result.getGedaiArari2Kg());
                        exResult.setJyo12daiKg(muwb3010Result.getJyodaiKg());
                        exResult.setJyo12daiArariKg(muwb3010Result.getJyodaiArariKg());
                        exResult.setJyo12dai2Kg(muwb3010Result.getJyodai2Kg());
                        exResult.setJyo12daiArari2Kg(muwb3010Result.getJyodaiArari2Kg());
                        break;
                    default:
                        break;
                }
            }
            exResultList.add(exResult);
        }
        return exResultList;
    }

    /**
     * 全ての選択した予算チェックする
     * 
     * @param y1
     * @param y2
     * @return
     */
    private Boolean isYosanAllCheck(String y1, String y2) {
        // 予算１選択
        final Boolean yoSan1Chk = StringUtils.equals(y1, SystemConsts.YOSAN_1);
        // 予算２選択
        final Boolean yoSan2Chk = StringUtils.equals(y2, SystemConsts.YOSAN_2);

        // 全ての予算を選択するかどうか、をチェックする
        if ((yoSan1Chk && yoSan2Chk) || (!yoSan1Chk && !yoSan2Chk)) {
            return true;
        } 
        // 予算１または予算２のみ選択するかどうかチェックする
        else {
            return false;
        }
    }

    /**
     * @param value
     * @return
     */
    private Long parseLongZero(String value) {
        return StringUtils.isBlank(value) ? 0L : Long.parseLong(value);
    }

    private String getFieldValue(MUWB3010ExResult exResult, String fieldName) {
        try {
            Field field = MUWB3010ExResult.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            String value = (String) field.get(exResult);
            return value;
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new AplRollbackException();
        }
    }
}
